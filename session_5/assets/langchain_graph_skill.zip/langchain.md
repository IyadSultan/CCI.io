# LangChain Reference (Python)

Covers `create_agent()`, tool definitions, middleware (HITL, custom hooks), structured output, and RAG pipelines. All examples are Python and target LangChain 1.0+.

## Contents

1. [Creating Agents with `create_agent`](#1-creating-agents-with-create_agent)
2. [Defining Tools](#2-defining-tools)
3. [Structured Output](#3-structured-output)
4. [Middleware](#4-middleware)
5. [Human-in-the-Loop](#5-human-in-the-loop)
6. [Custom Middleware Hooks](#6-custom-middleware-hooks)
7. [RAG — Indexing](#7-rag--indexing)
8. [RAG — Retrieval](#8-rag--retrieval)
9. [RAG + Agent](#9-rag--agent)
10. [Common Fixes](#10-common-fixes)

---

## 1. Creating Agents with `create_agent`

`create_agent()` is the recommended way to build an agent. It handles the agent loop, tool execution, and state management. **Do NOT use** `AgentExecutor`, `initialize_agent`, or `create_react_agent` — they are deprecated.

### Configuration options

| Parameter | Purpose | Example |
|-----------|---------|---------|
| `model` | LLM to use | `"anthropic:claude-sonnet-4-5"` or model instance |
| `tools` | List of tools | `[search, calculator]` |
| `system_prompt` | Agent instructions | `"You are a helpful assistant"` |
| `checkpointer` | State persistence | `MemorySaver()` |
| `middleware` | Processing hooks | `[HumanInTheLoopMiddleware(...)]` |
| `response_format` | Structured output schema | Pydantic model |

### Basic agent

```python
from langchain.agents import create_agent
from langchain_core.tools import tool

@tool
def get_weather(location: str) -> str:
    """Get current weather for a location.

    Args:
        location: City name
    """
    return f"Weather in {location}: Sunny, 72F"

agent = create_agent(
    model="anthropic:claude-sonnet-4-5",
    tools=[get_weather],
    system_prompt="You are a helpful assistant.",
)

result = agent.invoke({
    "messages": [{"role": "user", "content": "What's the weather in Paris?"}]
})
print(result["messages"][-1].content)
```

### Agent with conversation memory

Use a checkpointer + `thread_id` to keep state across invocations:

```python
from langchain.agents import create_agent
from langgraph.checkpoint.memory import MemorySaver

agent = create_agent(
    model="anthropic:claude-sonnet-4-5",
    tools=[search],
    checkpointer=MemorySaver(),
)

config = {"configurable": {"thread_id": "user-123"}}
agent.invoke({"messages": [{"role": "user", "content": "My name is Alice"}]}, config=config)
result = agent.invoke({"messages": [{"role": "user", "content": "What's my name?"}]}, config=config)
# "Your name is Alice"
```

### Model configuration

`create_agent` accepts either a model string or a model instance:

```python
# String shorthand
agent = create_agent(model="anthropic:claude-sonnet-4-5", tools=[...])
agent = create_agent(model="openai:gpt-4.1", tools=[...])

# Model instance for custom params
from langchain_anthropic import ChatAnthropic
agent = create_agent(
    model=ChatAnthropic(model="claude-sonnet-4-5", temperature=0),
    tools=[...],
)
```

---

## 2. Defining Tools

Use the `@tool` decorator. Clear descriptions and type-annotated arguments are what the model uses to decide when to call the tool.

```python
from langchain_core.tools import tool

@tool
def add(a: float, b: float) -> float:
    """Add two numbers.

    Args:
        a: First number
        b: Second number
    """
    return a + b
```

### Tool description best practices

- Describe **what the tool does** AND **when to use it**.
- Document every argument with `Args:`.
- Keep descriptions concrete — vague ("does stuff") tools get skipped or misused.

```python
# WRONG: vague
@tool
def bad_tool(input: str) -> str:
    """Does stuff."""
    return "result"

# CORRECT: specific purpose + trigger condition
@tool
def search(query: str) -> str:
    """Search the web for current information about a topic.

    Use this when you need recent data or facts.

    Args:
        query: The search query (2-10 words recommended)
    """
    return web_search(query)
```

---

## 3. Structured Output

Two options:

**(a) Agent with `response_format`** — the agent returns both text messages and a validated structured object:

```python
from langchain.agents import create_agent
from pydantic import BaseModel, Field

class ContactInfo(BaseModel):
    name: str
    email: str
    phone: str = Field(description="Phone number with area code")

agent = create_agent(model="gpt-4.1", tools=[search], response_format=ContactInfo)
result = agent.invoke({"messages": [{"role": "user", "content": "Find contact for John"}]})
print(result["structured_response"])  # ContactInfo(name='John', ...)
```

**(b) Model-level `with_structured_output()`** — no agent loop, just extraction:

```python
from langchain_openai import ChatOpenAI

model = ChatOpenAI(model="gpt-4.1")
structured_model = model.with_structured_output(ContactInfo)
response = structured_model.invoke("Extract: John, john@example.com, 555-1234")
# ContactInfo(name='John', email='john@example.com', phone='555-1234')
```

Use (b) for pure extraction tasks — it's cheaper and more reliable than invoking a full agent.

---

## 4. Middleware

Middleware intercepts the agent loop to add human approval, error handling, logging, retry logic, and more. Two main patterns:

- **Pre-built middleware** like `HumanInTheLoopMiddleware`
- **Custom middleware** via decorator hooks: `@before_model`, `@after_model`, `@wrap_tool_call`, `@wrap_model_call`, `@before_agent`, `@after_agent`

Key imports:

```python
from langchain.agents.middleware import (
    HumanInTheLoopMiddleware,
    wrap_tool_call,
    wrap_model_call,
    before_model,
    after_model,
    before_agent,
    after_agent,
)
```

---

## 5. Human-in-the-Loop

Pause before dangerous tool calls for human approval.

### Setup

```python
from langchain.agents import create_agent
from langchain.agents.middleware import HumanInTheLoopMiddleware
from langgraph.checkpoint.memory import MemorySaver
from langchain_core.tools import tool

@tool
def send_email(to: str, subject: str, body: str) -> str:
    """Send an email."""
    return f"Email sent to {to}"

agent = create_agent(
    model="gpt-4.1",
    tools=[send_email],
    checkpointer=MemorySaver(),  # REQUIRED for HITL
    middleware=[
        HumanInTheLoopMiddleware(
            interrupt_on={
                "send_email": {"allowed_decisions": ["approve", "edit", "reject"]},
            }
        )
    ],
)
```

### Running with interrupts

```python
from langgraph.types import Command

config = {"configurable": {"thread_id": "session-1"}}

# Step 1: run until the agent proposes a tool call — execution pauses
result1 = agent.invoke(
    {"messages": [{"role": "user", "content": "Send email to john@example.com"}]},
    config=config,
)

# Check for the interrupt payload
if "__interrupt__" in result1:
    print(f"Waiting for approval: {result1['__interrupt__']}")

# Step 2: approve and resume
result2 = agent.invoke(
    Command(resume={"decisions": [{"type": "approve"}]}),
    config=config,
)
```

### Editing tool arguments before approving

```python
result2 = agent.invoke(
    Command(resume={
        "decisions": [{
            "type": "edit",
            "edited_action": {
                "name": "send_email",
                "args": {
                    "to": "alice@company.com",  # Fixed
                    "subject": "Project Meeting - Updated",
                    "body": "...",
                },
            },
        }]
    }),
    config=config,
)
```

### Rejecting with feedback

```python
result2 = agent.invoke(
    Command(resume={
        "decisions": [{
            "type": "reject",
            "feedback": "Cannot delete customer data without manager approval",
        }]
    }),
    config=config,
)
```

### Per-tool policies

```python
agent = create_agent(
    model="gpt-4.1",
    tools=[send_email, read_email, delete_email],
    checkpointer=MemorySaver(),
    middleware=[
        HumanInTheLoopMiddleware(
            interrupt_on={
                "send_email": {"allowed_decisions": ["approve", "edit", "reject"]},
                "delete_email": {"allowed_decisions": ["approve", "reject"]},  # No edit
                "read_email": False,  # No HITL for reading
            }
        )
    ],
)
```

### HITL requirements checklist

1. `checkpointer=MemorySaver()` (or PostgresSaver in production).
2. `config={"configurable": {"thread_id": "..."}}` on every invoke.
3. Resume with `Command(resume=...)`, not a plain dict.
4. Interrupts happen BETWEEN `invoke()` calls — check for `__interrupt__` after each call.

---

## 6. Custom Middleware Hooks

Six decorator hooks. Two signatures:

**Wrap hooks** (`wrap_tool_call`, `wrap_model_call`): `(request, handler)` — call `handler(request)` to proceed, or return early to short-circuit.

**Before/after hooks** (`before_model`, `after_model`, `before_agent`, `after_agent`): `(state, runtime)` — inspect or modify state. Return `None` or a dict of state updates.

### Retry with `wrap_tool_call`

```python
from langchain.agents.middleware import wrap_tool_call

@wrap_tool_call
def retry_middleware(request, handler):
    for attempt in range(3):
        try:
            return handler(request)
        except Exception:
            if attempt == 2:
                raise
```

### Short-circuit a dangerous tool

```python
@wrap_tool_call
def guard_middleware(request, handler):
    if request.tool_call["name"] == "dangerous_tool":
        return "This tool is disabled"  # short-circuit, never calls handler
    return handler(request)
```

> **Do NOT use `yield` inside `@wrap_tool_call`.** It creates a generator and causes `NotImplementedError`.

### Before/after hooks

```python
from langchain.agents.middleware import before_model, after_model

@before_model
def log_calls(state, runtime):
    print(f"Calling model with {len(state['messages'])} messages")

@after_model
def check_output(state, runtime):
    print("Model responded")
```

---

## 7. RAG — Indexing

The pipeline:

1. **Load** documents
2. **Split** into chunks
3. **Embed** and **store**

### Vector store selection

| Store | Use case | Persistence |
|-------|----------|-------------|
| `InMemoryVectorStore` | Testing | Memory only |
| `FAISS` | Local, high performance | Disk |
| `Chroma` | Development | Disk |
| `Pinecone` | Production, managed | Cloud |

### Document loaders

```python
# PDF
from langchain_community.document_loaders import PyPDFLoader
loader = PyPDFLoader("./document.pdf")
docs = loader.load()

# Web page
from langchain_community.document_loaders import WebBaseLoader
loader = WebBaseLoader("https://docs.langchain.com")
docs = loader.load()

# Directory of text files
from langchain_community.document_loaders import DirectoryLoader, TextLoader
loader = DirectoryLoader("path/to/documents", glob="**/*.txt", loader_cls=TextLoader)
docs = loader.load()
```

### Text splitting

`RecursiveCharacterTextSplitter` is the default. Chunk size 500–1500 is usually right; always use overlap (10–20% of chunk size) to keep context at boundaries.

```python
from langchain_text_splitters import RecursiveCharacterTextSplitter

splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200,
    separators=["\n\n", "\n", " ", ""],
)
splits = splitter.split_documents(docs)
```

### Embeddings + vector store

```python
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma

embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

# Persistent Chroma
vectorstore = Chroma.from_documents(
    documents=splits,
    embedding=embeddings,
    persist_directory="./chroma_db",
    collection_name="my-collection",
)

# Reload later
vectorstore = Chroma(
    persist_directory="./chroma_db",
    embedding_function=embeddings,
    collection_name="my-collection",
)
```

FAISS alternative:

```python
from langchain_community.vectorstores import FAISS

vectorstore = FAISS.from_documents(splits, embeddings)
vectorstore.save_local("./faiss_index")

# Reload — requires allow_dangerous_deserialization
loaded = FAISS.load_local(
    "./faiss_index",
    embeddings,
    allow_dangerous_deserialization=True,
)
```

**Use the SAME embedding model for indexing and querying.** Mismatched dimensions = garbage results (or errors).

---

## 8. RAG — Retrieval

### Basic retriever

```python
retriever = vectorstore.as_retriever(search_kwargs={"k": 4})
relevant_docs = retriever.invoke("What is RAG?")
```

### Similarity search with scores

```python
results = vectorstore.similarity_search_with_score("my query", k=5)
for doc, score in results:
    print(f"Score: {score}, Content: {doc.page_content}")
```

### MMR (diversity-aware)

MMR balances relevance against diversity — useful when top-k results are near-duplicates:

```python
retriever = vectorstore.as_retriever(
    search_type="mmr",
    search_kwargs={"fetch_k": 20, "lambda_mult": 0.5, "k": 5},
)
```

### Metadata filtering

```python
from langchain_core.documents import Document

docs = [
    Document(
        page_content="Python programming guide",
        metadata={"language": "python", "topic": "programming"},
    ),
]

results = vectorstore.similarity_search(
    "programming",
    k=5,
    filter={"language": "python"},
)
```

---

## 9. RAG + Agent

Wrap a retriever as a tool and give it to an agent:

```python
from langchain.agents import create_agent
from langchain_core.tools import tool

@tool
def search_docs(query: str) -> str:
    """Search documentation for relevant information."""
    docs = retriever.invoke(query)
    return "\n\n".join(d.page_content for d in docs)

agent = create_agent(model="gpt-4.1", tools=[search_docs])
result = agent.invoke({
    "messages": [{"role": "user", "content": "How do I create an agent?"}]
})
```

### End-to-end example

```python
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

# 1. Load
docs = [
    Document(page_content="LangChain is a framework for LLM apps."),
    Document(page_content="RAG = Retrieval Augmented Generation."),
]

# 2. Split
splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
splits = splitter.split_documents(docs)

# 3. Embed + store
embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
vectorstore = InMemoryVectorStore.from_documents(splits, embeddings)

# 4. Retrieve
retriever = vectorstore.as_retriever(search_kwargs={"k": 4})

# 5. Generate
model = ChatOpenAI(model="gpt-4.1")
query = "What is RAG?"
context = "\n\n".join(d.page_content for d in retriever.invoke(query))
response = model.invoke([
    {"role": "system", "content": f"Use this context:\n\n{context}"},
    {"role": "user", "content": query},
])
```

---

## 10. Common Fixes

### Missing tool description → tool gets skipped

Clear, specific descriptions with `Args:` are what the model uses to route.

### Agent forgets between calls

Add a checkpointer + thread_id:

```python
# WRONG: no persistence
agent = create_agent(model="...", tools=[...])
agent.invoke({"messages": [...]})
agent.invoke({"messages": [...]})  # Doesn't remember!

# CORRECT
agent = create_agent(model="...", tools=[...], checkpointer=MemorySaver())
config = {"configurable": {"thread_id": "session-1"}}
agent.invoke({"messages": [...]}, config=config)
agent.invoke({"messages": [...]}, config=config)  # Remembers
```

### Agent loops forever

Set `recursion_limit` in the invoke config:

```python
result = agent.invoke(
    {"messages": [("user", "Do research")]},
    config={"recursion_limit": 10},
)
```

### Accessing the result wrong

The result is a dict with a `messages` list — not an object with `.content`:

```python
# WRONG
print(result.content)  # AttributeError

# CORRECT
print(result["messages"][-1].content)
```

### HITL fails silently

HITL requires a checkpointer AND a thread_id. Resume with `Command`, not a dict.

### RAG chunk size too small / too large

50-char chunks lose context; 10000-char chunks blow token budgets. Default to `chunk_size=1000, chunk_overlap=200`.

### Mixed embedding models in the same store

Indexing and querying must use the exact same embedding model. Switching from `text-embedding-3-small` to `text-embedding-3-large` requires re-indexing the entire store.

### `FAISS.load_local` errors without `allow_dangerous_deserialization`

FAISS uses pickle. Opt in explicitly:

```python
loaded = FAISS.load_local("./faiss_index", embeddings, allow_dangerous_deserialization=True)
```

### Deprecated community imports

Prefer dedicated packages:

```python
# WRONG
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_community.vectorstores import Chroma

# CORRECT
from langchain_tavily import TavilySearch
from langchain_chroma import Chroma
```
