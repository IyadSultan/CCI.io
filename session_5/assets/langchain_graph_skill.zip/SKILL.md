---
name: langchain-graph-skill
description: "Comprehensive Python guide for the LangChain / LangGraph / Deep Agents ecosystem. Use this skill whenever the user is building ANY agent, graph, or RAG application with these libraries — including create_agent, StateGraph, createDeepAgent, tool/middleware/subagent design, human-in-the-loop approval, checkpointer/Store persistence, document loaders and vector stores, or when they ask 'which framework should I use' or 'how do I install this'. Trigger even on casual phrasing ('build me an agent', 'I need a RAG pipeline', 'pause for human approval', 'remember across conversations', 'spawn parallel workers', 'fan out tasks'). Always consult this skill before writing any LangChain/LangGraph/Deep Agents code — it contains the correct modern APIs (LangChain 1.0+) and avoids deprecated patterns that the model is prone to emit from memory."
---

# LangChain / LangGraph / Deep Agents Skill

A three-layer Python skill covering the LangChain ecosystem. The layers build on each other — picking a higher layer does NOT cut you off from lower ones.

```
┌─────────────────────────────────────────┐
│              Deep Agents                │  ← batteries included: planning, memory, skills, files
├─────────────────────────────────────────┤
│               LangGraph                 │  ← orchestration: graphs, loops, state, HITL
├─────────────────────────────────────────┤
│               LangChain                 │  ← foundation: create_agent, tools, RAG
└─────────────────────────────────────────┘
```

## Step 1 — Pick the right layer FIRST

Answer these questions in order. Stop at the first YES.

| Question | If YES → |
|----------|----------|
| Does the task need task planning across sub-tasks, file management across a long session, persistent memory across sessions, or on-demand skill loading? | **Deep Agents** → read `references/deep-agents.md` |
| Does the task need custom control flow — loops, dynamic branching, parallel fan-out, human-in-the-loop at specific steps, persistent state across invocations? | **LangGraph** → read `references/langgraph.md` |
| Is this a single-purpose agent that takes input, runs tools, returns a result? Or a RAG pipeline? | **LangChain** → read `references/langchain.md` |

### Quick comparison

| | LangChain | LangGraph | Deep Agents |
|---|-----------|-----------|-------------|
| **Control flow** | Fixed (tool loop) | Custom (graph) | Managed (middleware) |
| **Planning** | ✗ | Manual | ✓ TodoListMiddleware |
| **File management** | ✗ | Manual | ✓ FilesystemMiddleware |
| **Persistent memory** | ✗ | With checkpointer | ✓ MemoryMiddleware |
| **Subagent delegation** | ✗ | Manual | ✓ SubAgentMiddleware |
| **On-demand skills** | ✗ | ✗ | ✓ SkillsMiddleware |
| **Human-in-the-loop** | ✗ | Manual interrupt | ✓ HumanInTheLoopMiddleware |
| **Custom graph edges** | ✗ | ✓ Full control | Limited |
| **Setup complexity** | Low | Medium | Low |

### Layers can be mixed

A LangGraph compiled graph can be registered as a Deep Agents subagent. LangChain tools and retrievers plug into both. When a Deep Agent needs one tightly-controlled sub-workflow (e.g. a retrieval-and-verify loop), build that piece in LangGraph and hand it off as a subagent.

---

## Step 2 — Install the right packages

### Environment

- **Python 3.10+** required.
- **LangChain 1.0+** is the current LTS. Never start new projects on 0.3 — it is maintenance-only.

### Always required

```
langchain>=1.0,<2.0
langchain-core>=1.0,<2.0
langsmith>=0.3.0
```

### Orchestration — pick ONE

```
# For LangGraph
langgraph>=1.0,<2.0

# For Deep Agents (pulls in LangGraph transitively)
deepagents
```

### Model provider — pick the one(s) you use

| Package | Provider |
|---------|----------|
| `langchain-openai` | OpenAI (GPT-4.1, o3, ...) |
| `langchain-anthropic` | Anthropic (Claude) |
| `langchain-azure-ai` | Azure OpenAI / Azure AI Foundry |
| `langchain-google-genai` | Gemini |
| `langchain-ollama` | Ollama (local) |
| `langchain-aws` | Bedrock |

For AIDI/KHCC clinical pipelines, Azure OpenAI via `langchain-azure-ai` is the default (matches the `gpt-4.1-mini` deployment on `openai-aidi.openai.azure.com`).

### Tools & retrieval (install only if needed)

| Package | Use |
|---------|-----|
| `langchain-tavily` | Web search |
| `langchain-text-splitters` | Text chunking |
| `langchain-chroma` | Chroma vector store |
| `langchain-pinecone` | Pinecone vector store |
| `langchain-qdrant` | Qdrant vector store |
| `faiss-cpu` | FAISS vector store (via community) |
| `langchain-community` | 1000+ integrations (fallback) |

### Versioning & upgrade rules

| Package group | Strategy |
|---------------|----------|
| `langchain`, `langchain-core`, `langgraph` | Semver — pin minor: `>=1.0,<2.0` |
| `langsmith` | Semver — allow minor: `>=0.3.0` |
| Dedicated integrations (`langchain-tavily`, `langchain-chroma`, etc.) | Independently versioned, use latest |
| `langchain-community` | **NOT semver** — pin exact minor: `>=0.4.0,<0.5.0` |

**Prefer dedicated integration packages over langchain-community.** When `langchain-chroma` exists, use it instead of importing Chroma from `langchain-community` — dedicated packages are better versioned and better tested. Search https://python.langchain.com/docs/integrations/tools/ for the canonical import path.

### Common deprecated imports to avoid

```python
# WRONG — deprecated community paths
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_community.vectorstores import Chroma
from langchain_community.vectorstores import Pinecone

# CORRECT — dedicated packages
from langchain_tavily import TavilySearch
from langchain_chroma import Chroma
from langchain_pinecone import PineconeVectorStore
```

### Environment variables

Set only the keys for services actually used:

```bash
# Observability (recommended)
LANGSMITH_API_KEY=<key>
LANGSMITH_PROJECT=<project>

# Providers
OPENAI_API_KEY=<key>
ANTHROPIC_API_KEY=<key>
AZURE_OPENAI_API_KEY=<key>       # for Azure
AZURE_OPENAI_ENDPOINT=<endpoint>
GOOGLE_API_KEY=<key>

# Tools
TAVILY_API_KEY=<key>
PINECONE_API_KEY=<key>
```

---

## Step 3 — Load the right reference file

Once Step 1 identifies the layer, load the matching reference file BEFORE writing code:

| If you're working on... | Read this file |
|------------------------|----------------|
| `create_agent()`, tools, middleware, RAG, document loaders, vector stores, embeddings, structured output | `references/langchain.md` |
| `StateGraph`, nodes, edges, `Command`, `Send`, streaming, `interrupt()` / `Command(resume=...)`, checkpointers, `Store`, time travel, subgraph checkpointer scoping | `references/langgraph.md` |
| `create_deep_agent()`, subagents, TodoList, SKILL.md format for deep-agent skills, `StateBackend` / `StoreBackend` / `FilesystemBackend` / `CompositeBackend`, Deep Agents HITL | `references/deep-agents.md` |

Often two files are relevant. Example: "Build a Deep Agent whose research subagent is a LangGraph retrieval loop" → read both `deep-agents.md` and `langgraph.md`.

---

## Critical rules that apply across ALL layers

These are the mistakes the model is most likely to make from training-data memory. Internalize them before writing any code:

1. **`create_agent()` is the only correct LangChain agent constructor.** The older `AgentExecutor`, `initialize_agent`, `create_react_agent`, `create_openai_tools_agent` APIs are deprecated. Do not use them.

2. **Persistence requires BOTH a checkpointer AND a `thread_id`.** Forgetting either means state does not persist. Every HITL / memory / multi-turn example needs:
   ```python
   graph = builder.compile(checkpointer=MemorySaver())
   graph.invoke(input, config={"configurable": {"thread_id": "..."}})
   ```

3. **Nodes return partial state updates, not the mutated state object.** Do NOT mutate `state` in place and return it.

4. **List fields in state need a reducer**, otherwise each node's write OVERWRITES the previous value. Use `Annotated[list, operator.add]` or the built-in `MessagesState` / `add_messages`.

5. **`interrupt()` restarts the node from the beginning when resumed.** Any code before `interrupt()` re-runs. Put side effects AFTER the interrupt, or make them idempotent (upsert, not insert).

6. **Resume an interrupt with `Command(resume=...)`, not a plain dict.** A plain dict starts a new run.

7. **`InMemorySaver` is dev-only.** For production, use `PostgresSaver` (or SQLite for single-user local).

8. **Deep Agents `StoreBackend` requires a `Store` instance.** Passing only `backend=lambda rt: StoreBackend(rt)` without `store=InMemoryStore()` fails silently.

9. **Custom Deep Agents subagents do NOT inherit skills** from the main agent. Pass `skills=[...]` explicitly to each subagent.

10. **Recursion limit.** Always set `config={"recursion_limit": 25}` (or similar) when invoking agents to prevent runaway loops.

---

## File index

- `SKILL.md` (this file) — router, framework selection, dependencies, cross-cutting rules
- `references/langchain.md` — `create_agent`, tools, middleware, structured output, RAG
- `references/langgraph.md` — StateGraph, state, edges, Command, Send, streaming, HITL, persistence, subgraph scoping
- `references/deep-agents.md` — `create_deep_agent`, backends, subagents, TodoList, HITL, SKILL.md format for deep-agent skills
