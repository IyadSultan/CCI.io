# LangGraph Reference (Python)

Covers `StateGraph`, state management, nodes, edges, `Command`, `Send`, streaming, error handling, human-in-the-loop interrupts, and persistence (checkpointer, Store, subgraph scoping). All examples are Python.

## Contents

1. [When to use LangGraph](#1-when-to-use-langgraph)
2. [Design methodology](#2-design-methodology)
3. [State management](#3-state-management)
4. [Nodes](#4-nodes)
5. [Edges](#5-edges)
6. [Command — update + route in one return](#6-command--update--route-in-one-return)
7. [Send API — fan-out](#7-send-api--fan-out)
8. [Running: invoke and stream](#8-running-invoke-and-stream)
9. [Error handling](#9-error-handling)
10. [Human-in-the-loop: interrupts](#10-human-in-the-loop-interrupts)
11. [Persistence: checkpointers, threads, time travel](#11-persistence-checkpointers-threads-time-travel)
12. [Long-term memory: Store](#12-long-term-memory-store)
13. [Subgraph checkpointer scoping](#13-subgraph-checkpointer-scoping)
14. [Common fixes](#14-common-fixes)

---

## 1. When to use LangGraph

| Use LangGraph when | Use alternatives when |
|--------------------|-----------------------|
| Need fine-grained control over orchestration | Quick prototyping → plain LangChain `create_agent` |
| Building workflows with branching or loops | Simple stateless workflows → plain LangChain |
| Need HITL, persistence, parallel fan-out | Batteries-included → Deep Agents |

---

## 2. Design methodology

Five steps when building a new graph:

1. **Map out discrete steps** — sketch a flowchart. Each step becomes a node.
2. **Categorize each node** — LLM step, data step, action step, or user-input step. For each, determine static context (prompt), dynamic context (from state), retry strategy, and desired outcome.
3. **Design your state** — state is shared memory for all nodes. Store raw data; format prompts on-demand inside nodes.
4. **Build your nodes** — each is a function taking state, returning partial updates.
5. **Wire it together** — connect with edges, add conditional routing, compile with a checkpointer if needed.

---

## 3. State management

### Update strategies

| Need | Solution | Example |
|------|----------|---------|
| Overwrite value | No reducer (default) | Simple fields like counters |
| Append to list | Reducer (`operator.add`) | Message history, logs |
| Custom merge logic | Custom reducer function | Complex merging |

### State with reducers

```python
from typing_extensions import TypedDict, Annotated
import operator

class State(TypedDict):
    name: str                                    # Default: overwrites on update
    messages: Annotated[list, operator.add]      # Appends to list
    total: Annotated[int, operator.add]          # Sums integers
```

### Messages shortcut

For chat-style graphs use `MessagesState` which has the correct reducer built in:

```python
from langgraph.graph import MessagesState
# MessagesState = TypedDict with `messages: Annotated[list, add_messages]`
```

### The single most common mistake: forgetting the reducer

Without a reducer, a list field is **overwritten**, not appended:

```python
# WRONG — "A" is lost when node 2 writes ["B"]
class State(TypedDict):
    messages: list

# CORRECT
from typing import Annotated
import operator

class State(TypedDict):
    messages: Annotated[list, operator.add]
```

### Nodes return partial updates, not mutated state

```python
# WRONG
def my_node(state: State) -> State:
    state["field"] = "updated"
    return state

# CORRECT
def my_node(state: State) -> dict:
    return {"field": "updated"}
```

---

## 4. Nodes

Nodes are plain Python functions. They accept one of three signatures:

| Signature | When to use |
|-----------|-------------|
| `def node(state: State)` | Only needs state |
| `def node(state: State, config: RunnableConfig)` | Needs `thread_id`, tags, or configurable values |
| `def node(state: State, runtime: Runtime[Context])` | Needs runtime context, `store`, or `stream_writer` |

```python
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime

def plain_node(state: State):
    return {"results": "done"}

def node_with_config(state: State, config: RunnableConfig):
    thread_id = config["configurable"]["thread_id"]
    return {"results": f"Thread: {thread_id}"}

def node_with_runtime(state: State, runtime: Runtime):
    user_id = runtime.context.user_id
    return {"results": f"User: {user_id}"}
```

---

## 5. Edges

| Need | Edge type | When to use |
|------|-----------|-------------|
| Always go to same node | `add_edge()` | Fixed, deterministic flow |
| Route based on state | `add_conditional_edges()` | Dynamic branching |
| Update state AND route | `Command` (see §6) | Combine logic in single node |
| Fan-out to many nodes | `Send` (see §7) | Parallel processing with dynamic inputs |

### Basic linear graph

```python
from langgraph.graph import StateGraph, START, END
from typing_extensions import TypedDict

class State(TypedDict):
    input: str
    output: str

def process_input(state: State) -> dict:
    return {"output": f"Processed: {state['input']}"}

def finalize(state: State) -> dict:
    return {"output": state["output"].upper()}

graph = (
    StateGraph(State)
    .add_node("process", process_input)
    .add_node("finalize", finalize)
    .add_edge(START, "process")
    .add_edge("process", "finalize")
    .add_edge("finalize", END)
    .compile()
)

result = graph.invoke({"input": "hello"})  # "PROCESSED: HELLO"
```

### Conditional edges

```python
from typing import Literal

class State(TypedDict):
    query: str
    route: str
    result: str

def classify(state: State) -> dict:
    if "weather" in state["query"].lower():
        return {"route": "weather"}
    return {"route": "general"}

def route_query(state: State) -> Literal["weather", "general"]:
    return state["route"]

graph = (
    StateGraph(State)
    .add_node("classify", classify)
    .add_node("weather", lambda s: {"result": "Sunny, 72F"})
    .add_node("general", lambda s: {"result": "General response"})
    .add_edge(START, "classify")
    .add_conditional_edges("classify", route_query, ["weather", "general"])
    .add_edge("weather", END)
    .add_edge("general", END)
    .compile()
)
```

---

## 6. Command — update + route in one return

`Command` lets a node both update state AND choose the next node in one return value.

Fields:
- **`update`**: state updates to apply
- **`goto`**: next node name (or list of names)
- **`resume`**: value to resume after `interrupt()` — see §10

```python
from langgraph.types import Command
from typing import Literal

class State(TypedDict):
    count: int
    result: str

def node_a(state: State) -> Command[Literal["node_b", "node_c"]]:
    new_count = state["count"] + 1
    if new_count > 5:
        return Command(update={"count": new_count}, goto="node_c")
    return Command(update={"count": new_count}, goto="node_b")

graph = (
    StateGraph(State)
    .add_node("node_a", node_a)
    .add_node("node_b", lambda s: {"result": "B"})
    .add_node("node_c", lambda s: {"result": "C"})
    .add_edge(START, "node_a")
    .add_edge("node_b", END)
    .add_edge("node_c", END)
    .compile()
)
```

> Use `Command[Literal["node_a", "node_b"]]` as the return type to declare valid `goto` destinations.

### Warning: Command does NOT override static edges

`Command` adds a **dynamic** edge — static `add_edge()` edges still execute. If `node_a` returns `Command(goto="node_c")` AND you have `graph.add_edge("node_a", "node_b")`, BOTH `node_b` and `node_c` run.

---

## 7. Send API — fan-out

Return `[Send("worker", {...}), Send("worker", {...})]` from a conditional edge to spawn parallel workers. Each gets its own input dict.

Requires a reducer on the results field — otherwise the last worker overwrites all the others.

```python
from langgraph.types import Send
from typing import Annotated
import operator

class OrchestratorState(TypedDict):
    tasks: list[str]
    results: Annotated[list, operator.add]   # Reducer is essential
    summary: str

def orchestrator(state: OrchestratorState):
    return [Send("worker", {"task": t}) for t in state["tasks"]]

def worker(state: dict) -> dict:
    return {"results": [f"Completed: {state['task']}"]}

def synthesize(state: OrchestratorState) -> dict:
    return {"summary": f"Processed {len(state['results'])} tasks"}

graph = (
    StateGraph(OrchestratorState)
    .add_node("worker", worker)
    .add_node("synthesize", synthesize)
    .add_conditional_edges(START, orchestrator, ["worker"])
    .add_edge("worker", "synthesize")
    .add_edge("synthesize", END)
    .compile()
)

result = graph.invoke({"tasks": ["Task A", "Task B", "Task C"]})
```

---

## 8. Running: invoke and stream

### Invoke (run to completion)

```python
result = graph.invoke({"input": "hello"})

# With config for persistence
result = graph.invoke(
    {"input": "hello"},
    {"configurable": {"thread_id": "1"}},
)
```

### Stream modes

| Mode | What it streams | Use case |
|------|----------------|----------|
| `values` | Full state after each step | Monitor complete state |
| `updates` | State deltas | Track incremental updates |
| `messages` | LLM tokens + metadata | Chat UIs |
| `custom` | User-defined data | Progress indicators |

### Stream LLM tokens

```python
from langchain_core.messages import HumanMessage

for chunk in graph.stream(
    {"messages": [HumanMessage("Hello")]},
    stream_mode="messages",
):
    token, metadata = chunk
    if hasattr(token, "content"):
        print(token.content, end="", flush=True)
```

### Stream custom progress

```python
from langgraph.config import get_stream_writer

def my_node(state):
    writer = get_stream_writer()
    writer("Processing step 1...")
    writer("Complete!")
    return {"result": "done"}

for chunk in graph.stream({"data": "test"}, stream_mode="custom"):
    print(chunk)
```

---

## 9. Error handling

Match the error type to the right handler:

| Error type | Who fixes | Strategy |
|------------|-----------|----------|
| Transient (network, rate limits) | System | `RetryPolicy(max_attempts=3)` |
| LLM-recoverable (tool failure) | LLM | `ToolNode(tools, handle_tool_errors=True)` |
| User-fixable (missing info) | Human | `interrupt(...)` — see §10 |
| Unexpected bugs | Developer | Let it bubble up |

### RetryPolicy for transient errors

```python
from langgraph.types import RetryPolicy

workflow.add_node(
    "search_documentation",
    search_documentation,
    retry_policy=RetryPolicy(max_attempts=3, initial_interval=1.0),
)
```

### ToolNode for LLM-recoverable tool errors

When `handle_tool_errors=True`, errors come back as `ToolMessage`s — the LLM can see the error text and try again.

```python
from langgraph.prebuilt import ToolNode

tool_node = ToolNode(tools, handle_tool_errors=True)
workflow.add_node("tools", tool_node)
```

---

## 10. Human-in-the-loop: interrupts

`interrupt(value)` pauses the graph. The value surfaces under `__interrupt__` in the result. `Command(resume=value)` resumes — the resume value becomes the return value of `interrupt()`.

### Requirements

1. Compile with a **checkpointer**.
2. Every invoke/stream call needs a **`thread_id`**.
3. The value passed to `interrupt()` must be **JSON-serializable**.

### Basic interrupt + resume

```python
from langgraph.types import interrupt, Command
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import StateGraph, START, END
from typing_extensions import TypedDict

class State(TypedDict):
    approved: bool

def approval_node(state: State):
    approved = interrupt("Do you approve this action?")
    return {"approved": approved}

graph = (
    StateGraph(State)
    .add_node("approval", approval_node)
    .add_edge(START, "approval")
    .add_edge("approval", END)
    .compile(checkpointer=InMemorySaver())
)

config = {"configurable": {"thread_id": "thread-1"}}

# Initial run — hits interrupt
result = graph.invoke({"approved": False}, config)
print(result["__interrupt__"])  # [Interrupt(value='Do you approve this action?')]

# Resume
result = graph.invoke(Command(resume=True), config)
print(result["approved"])  # True
```

### Approval workflow with routing

```python
from langgraph.types import interrupt, Command
from typing import Literal

def human_review(state) -> Command[Literal["send_reply", "__end__"]]:
    human_decision = interrupt({
        "draft_response": state.get("draft_response", ""),
        "action": "Please review and approve/edit this response",
    })

    if human_decision.get("approved"):
        return Command(
            update={
                "draft_response": human_decision.get(
                    "edited_response", state.get("draft_response", "")
                ),
            },
            goto="send_reply",
        )
    else:
        return Command(update={}, goto=END)
```

### Validation loop

Re-prompt until the human provides valid input:

```python
def get_age_node(state):
    prompt = "What is your age?"
    while True:
        answer = interrupt(prompt)
        if isinstance(answer, int) and answer > 0:
            break
        prompt = f"'{answer}' is not a valid age. Please enter a positive number."
    return {"age": answer}
```

Each `Command(resume=...)` provides the next answer.

### Multiple parallel interrupts

When several parallel branches each call `interrupt()`, resume them all at once by mapping each interrupt ID to its resume value:

```python
result = graph.invoke({"vals": []}, config)

resume_map = {
    i.id: f"answer for {i.value}"
    for i in result["__interrupt__"]
}
result = graph.invoke(Command(resume=resume_map), config)
```

### The idempotency rule

**When the graph resumes, the interrupted node restarts from the beginning.** ALL code before `interrupt()` re-runs. In subgraphs, BOTH the parent node and the subgraph node re-execute.

Rules:
- Use **upsert**, not insert, before `interrupt()`.
- Use **check-before-create** patterns.
- Place side effects **after** `interrupt()` when possible.

```python
# GOOD — upsert is idempotent
def node_a(state: State):
    db.upsert_user(user_id=state["user_id"], status="pending_approval")
    approved = interrupt("Approve?")
    return {"approved": approved}

# GOOD — side effect AFTER interrupt
def node_a(state: State):
    approved = interrupt("Approve?")
    if approved:
        db.create_audit_log(user_id=state["user_id"], action="approved")
    return {"approved": approved}

# BAD — creates a duplicate row on every resume
def node_a(state: State):
    db.create_audit_log({"user_id": state["user_id"], "action": "pending"})
    approved = interrupt("Approve?")
    return {"approved": approved}
```

### Resume antipattern

`Command(resume=...)` is the ONLY Command pattern intended as input to `invoke()`. Do NOT pass `Command(update=...)` as input — it will resume from the latest checkpoint and the graph appears stuck.

---

## 11. Persistence: checkpointers, threads, time travel

The checkpointer saves state at every super-step. `thread_id` separates checkpoint sequences (conversations).

### Checkpointer selection

| Checkpointer | Use case | Production? |
|--------------|----------|-------------|
| `InMemorySaver` | Testing, dev | No — data lost on restart |
| `SqliteSaver` | Local single-user | Partial |
| `PostgresSaver` | Production | Yes |

### Basic setup

```python
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import StateGraph, START, END
from typing_extensions import TypedDict, Annotated
import operator

class State(TypedDict):
    messages: Annotated[list, operator.add]

graph = (
    StateGraph(State)
    .add_node("respond", lambda s: {"messages": ["Bot response"]})
    .add_edge(START, "respond")
    .add_edge("respond", END)
    .compile(checkpointer=InMemorySaver())
)

config = {"configurable": {"thread_id": "conversation-1"}}
graph.invoke({"messages": ["Hello"]}, config)
graph.invoke({"messages": ["How are you?"]}, config)  # Remembers previous
```

### Production Postgres

```python
from langgraph.checkpoint.postgres import PostgresSaver

with PostgresSaver.from_conn_string("postgresql://user:pass@localhost/db") as checkpointer:
    checkpointer.setup()   # only needed on first use (creates tables)
    graph = builder.compile(checkpointer=checkpointer)
```

### Separate threads = isolated state

```python
alice_config = {"configurable": {"thread_id": "user-alice"}}
bob_config   = {"configurable": {"thread_id": "user-bob"}}

graph.invoke({"messages": ["Hi from Alice"]}, alice_config)
graph.invoke({"messages": ["Hi from Bob"]}, bob_config)
# Alice and Bob have separate state.
```

### Time travel

```python
config = {"configurable": {"thread_id": "session-1"}}
result = graph.invoke({"messages": ["start"]}, config)

# Browse checkpoint history
states = list(graph.get_state_history(config))

# Replay from a past checkpoint
past = states[-2]
result = graph.invoke(None, past.config)   # None = resume from checkpoint

# Fork: update state at a past checkpoint, then resume
fork_config = graph.update_state(past.config, {"messages": ["edited"]})
result = graph.invoke(None, fork_config)
```

### update_state and reducers

`update_state` PASSES THROUGH reducers. If the field has `operator.add`, the update is appended. To REPLACE, use `Overwrite`:

```python
from langgraph.types import Overwrite

# Current: {"items": ["A", "B"]}
graph.update_state(config, {"items": ["C"]})                # ["A", "B", "C"]
graph.update_state(config, {"items": Overwrite(["C"])})     # ["C"]
```

---

## 12. Long-term memory: Store

`Store` is cross-thread memory — user preferences, facts — shared across conversations.

- **Checkpointer** = thread-scoped (conversation history)
- **Store** = cross-thread (user preferences, long-term facts)

```python
from langgraph.store.memory import InMemoryStore
from langgraph.runtime import Runtime

store = InMemoryStore()
store.put(("alice", "preferences"), "language", {"preference": "short responses"})

def respond(state, runtime: Runtime):
    prefs = runtime.store.get((state["user_id"], "preferences"), "language")
    return {"response": f"Using preference: {prefs.value}"}

# Compile with BOTH checkpointer and store
graph = builder.compile(checkpointer=checkpointer, store=store)

# Both threads see the same long-term memory
graph.invoke({"user_id": "alice"}, {"configurable": {"thread_id": "thread-1"}})
graph.invoke({"user_id": "alice"}, {"configurable": {"thread_id": "thread-2"}})
```

### Store operations

```python
store.put(("user-123", "facts"), "location", {"city": "San Francisco"})
item = store.get(("user-123", "facts"), "location")
results = store.search(("user-123", "facts"), filter={"city": "San Francisco"})
store.delete(("user-123", "facts"), "location")
```

---

## 13. Subgraph checkpointer scoping

When compiling a subgraph, the `checkpointer` argument controls its persistence behavior:

| Feature | `checkpointer=False` | `None` (default) | `checkpointer=True` |
|---|---|---|---|
| Interrupts (HITL) | No | Yes | Yes |
| Multi-turn memory | No | No | Yes |
| Multiple calls (different subgraphs) | Yes | Yes | Warning: namespace conflicts possible |
| Multiple calls (same subgraph) | Yes | Yes | No |
| State inspection | No | Current invocation only | Yes |

### When to pick each

- **`False`** — no interrupts, no persistence needed. Cheapest.
- **`None`** (omit the arg) — subgraph uses `interrupt()` but doesn't need cross-invocation memory.
- **`True`** — subgraph needs multi-turn memory (each call picks up where the last left off).

```python
# No interrupts, no persistence
subgraph = subgraph_builder.compile(checkpointer=False)

# Needs interrupts but not cross-invocation memory (default)
subgraph = subgraph_builder.compile()

# Stateful — remembers across invocations
subgraph = subgraph_builder.compile(checkpointer=True)
```

### Warning: stateful parallel subgraphs

Stateful subgraphs (`checkpointer=True`) do NOT support calling the **same subgraph instance** multiple times within a single node — calls write to the same checkpoint namespace and conflict.

### Parallel namespace pattern

When multiple **different** stateful subgraphs run in parallel, wrap each in its own `StateGraph` with a unique node name:

```python
from langgraph.graph import MessagesState, StateGraph

def create_sub_agent(model, *, name, **kwargs):
    agent = create_agent(model=model, name=name, **kwargs)
    return (
        StateGraph(MessagesState)
        .add_node(name, agent)   # unique name → stable namespace
        .add_edge("__start__", name)
        .compile()
    )

fruit_agent = create_sub_agent("gpt-4.1-mini", name="fruit_agent", tools=[fruit_info], prompt="...", checkpointer=True)
veggie_agent = create_sub_agent("gpt-4.1-mini", name="veggie_agent", tools=[veggie_info], prompt="...", checkpointer=True)
```

Subgraphs added as nodes via `add_node` already get name-based namespaces automatically.

---

## 14. Common fixes

### Forgetting to `compile()`

```python
# WRONG
builder.invoke({"input": "test"})   # AttributeError

# CORRECT
graph = builder.compile()
graph.invoke({"input": "test"})
```

### Infinite loop

```python
# WRONG — loops forever
builder.add_edge("node_a", "node_b")
builder.add_edge("node_b", "node_a")

# CORRECT — give it an exit
def should_continue(state):
    return END if state["count"] > 10 else "node_b"
builder.add_conditional_edges("node_a", should_continue)
```

### Router refers to a node that doesn't exist

Add the node BEFORE referencing it in an edge:

```python
builder.add_node("my_node", func)
builder.add_conditional_edges("node_a", router, ["my_node"])
```

### START can't be a destination

```python
# WRONG — START is entry-only
builder.add_edge("node_a", START)

# CORRECT — use a named entry node
builder.add_edge("node_a", "entry")
```

### Reducer type mismatch

A list reducer expects a list, not a string:

```python
return {"items": ["item"]}   # Correct for list reducer
```

### No thread_id → state doesn't persist

```python
# WRONG
graph.invoke({"messages": [...]})
graph.invoke({"messages": [...]})   # Doesn't remember

# CORRECT
config = {"configurable": {"thread_id": "session-1"}}
graph.invoke({"messages": [...]}, config)
graph.invoke({"messages": [...]}, config)
```

### InMemorySaver in production

Don't. Use `PostgresSaver` instead — `InMemorySaver` loses everything on restart.

### Interrupts without a checkpointer

Interrupts require a checkpointer. Always compile with one when using HITL:

```python
graph = builder.compile(checkpointer=InMemorySaver())
```

### Resuming with a plain dict instead of Command

```python
# WRONG — starts a new run
graph.invoke({"resume_data": "approve"}, config)

# CORRECT
from langgraph.types import Command
graph.invoke(Command(resume="approve"), config)
```

### Accessing store in a node

The store isn't a global — inject it via `runtime`:

```python
# WRONG
def my_node(state):
    store.put(...)   # NameError

# CORRECT
from langgraph.runtime import Runtime
def my_node(state, runtime: Runtime):
    runtime.store.put(...)
```

### Don't mutate state directly

Always return a partial update dict:

```python
# WRONG
def node(state):
    state["field"] = "x"
    return state

# CORRECT
def node(state):
    return {"field": "x"}
```
