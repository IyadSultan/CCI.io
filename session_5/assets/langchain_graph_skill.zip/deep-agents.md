# Deep Agents Reference (Python)

Covers `create_deep_agent()`, the middleware harness, file-system backends (State / Store / Filesystem / Composite), subagents, TodoList planning, HITL approvals, and the SKILL.md format for skills consumed by Deep Agents. All examples are Python.

## Contents

1. [Overview & when to use](#1-overview--when-to-use)
2. [Built-in middleware](#2-built-in-middleware)
3. [Creating a Deep Agent](#3-creating-a-deep-agent)
4. [Built-in tools](#4-built-in-tools)
5. [Backends for memory & files](#5-backends-for-memory--files)
6. [Subagents — task delegation](#6-subagents--task-delegation)
7. [TodoList — task planning](#7-todolist--task-planning)
8. [Human-in-the-loop in Deep Agents](#8-human-in-the-loop-in-deep-agents)
9. [Skills in Deep Agents (SKILL.md format)](#9-skills-in-deep-agents-skillmd-format)
10. [Common fixes](#10-common-fixes)

---

## 1. Overview & when to use

Deep Agents is an opinionated framework built on LangChain/LangGraph with a pre-wired middleware layer:

- **Task planning** — `TodoListMiddleware`
- **Context management** — `FilesystemMiddleware` (pluggable backends)
- **Task delegation** — `SubAgentMiddleware` (spawn specialized subagents)
- **Long-term memory** — `MemoryMiddleware` (persistent Store across threads)
- **Human-in-the-loop** — `HumanInTheLoopMiddleware`
- **Skills** — `SkillsMiddleware` (on-demand SKILL.md loading)

You **configure** these — you don't implement them.

| Use Deep Agents when | Use LangChain's create_agent when |
|---------------------|-----------------------------------|
| Multi-step tasks that require planning | Simple, single-purpose tasks |
| Large context requiring file management | Context fits in a single prompt |
| Need specialized subagents | One agent is sufficient |
| Persistent memory across sessions | Ephemeral single-session work |

---

## 2. Built-in middleware

| Middleware | Provides | Default? |
|------------|----------|----------|
| `TodoListMiddleware` | `write_todos` tool | Always on |
| `FilesystemMiddleware` | `ls`, `read_file`, `write_file`, `edit_file`, `glob`, `grep` | Always on |
| `SubAgentMiddleware` | `task` tool | Always on |
| `SkillsMiddleware` | On-demand SKILL.md loading | Opt-in |
| `MemoryMiddleware` | Long-term memory via `Store` | Opt-in |
| `HumanInTheLoopMiddleware` | Approval interrupts | Opt-in |

---

## 3. Creating a Deep Agent

### Minimal example

```python
from deepagents import create_deep_agent
from langchain.tools import tool

@tool
def get_weather(city: str) -> str:
    """Get the weather for a given city."""
    return f"It is always sunny in {city}"

agent = create_deep_agent(
    model="claude-sonnet-4-5-20250929",
    tools=[get_weather],
    system_prompt="You are a helpful assistant",
)

config = {"configurable": {"thread_id": "user-123"}}
result = agent.invoke(
    {"messages": [{"role": "user", "content": "What's the weather in Tokyo?"}]},
    config=config,
)
```

### Full configuration

```python
from deepagents import create_deep_agent
from deepagents.backends import FilesystemBackend
from langgraph.checkpoint.memory import MemorySaver
from langgraph.store.memory import InMemoryStore

agent = create_deep_agent(
    name="my-assistant",
    model="claude-sonnet-4-5-20250929",
    tools=[custom_tool1, custom_tool2],
    system_prompt="Custom instructions",
    subagents=[research_agent, code_agent],
    backend=FilesystemBackend(root_dir=".", virtual_mode=True),
    interrupt_on={"write_file": True},
    skills=["./skills/"],
    checkpointer=MemorySaver(),
    store=InMemoryStore(),
)
```

### What you CAN configure

- Model selection and parameters
- Additional custom tools
- System prompt
- Backend storage strategy
- Which tools require HITL approval
- Custom subagents with their own tools

### What you CANNOT configure

- Remove core middleware (TodoList / Filesystem / SubAgent are always present)
- Rename built-in tools (`write_todos`, `task`, filesystem tools)

---

## 4. Built-in tools

Every Deep Agent automatically has:

1. **Planning** — `write_todos`
2. **Filesystem** — `ls`, `read_file`, `write_file`, `edit_file`, `glob`, `grep`
3. **Delegation** — `task` (spawn a subagent)

---

## 5. Backends for memory & files

The `FilesystemMiddleware` uses a pluggable backend for file operations:

| Backend | Use case | Notes |
|---------|----------|-------|
| `StateBackend` | Temporary working files | Default, no setup — thread-scoped ephemeral |
| `FilesystemBackend` | Local dev CLI | Direct disk access — **security risk in web servers** |
| `StoreBackend` | Cross-session memory | Persists across threads, requires a `Store` |
| `CompositeBackend` | Hybrid | Route different paths to different backends |

### Default (StateBackend — ephemeral within a thread)

```python
from deepagents import create_deep_agent

agent = create_deep_agent()   # Default backend is StateBackend

result = agent.invoke(
    {"messages": [{"role": "user", "content": "Write notes to /draft.txt"}]},
    config={"configurable": {"thread_id": "thread-1"}},
)
# /draft.txt is lost when thread ends
```

### CompositeBackend — hybrid

Route `/memories/...` to a persistent StoreBackend while keeping other paths ephemeral:

```python
from deepagents import create_deep_agent
from deepagents.backends import CompositeBackend, StateBackend, StoreBackend
from langgraph.store.memory import InMemoryStore

store = InMemoryStore()
composite_backend = lambda rt: CompositeBackend(
    default=StateBackend(rt),
    routes={"/memories/": StoreBackend(rt)},
)

agent = create_deep_agent(backend=composite_backend, store=store)

# /draft.txt               → ephemeral (StateBackend)
# /memories/user-prefs.txt → persistent (StoreBackend)
```

CompositeBackend matches the LONGEST prefix first:

```python
routes = {"/mem/": StoreBackend(rt), "/mem/temp/": StateBackend(rt)}
# /mem/file.txt        → StoreBackend
# /mem/temp/file.txt   → StateBackend (longer match wins)
```

### Cross-session memory

Files in `/memories/...` are visible across threads via the StoreBackend route:

```python
config1 = {"configurable": {"thread_id": "thread-1"}}
agent.invoke({"messages": [{"role": "user", "content": "Save to /memories/style.txt"}]}, config=config1)

config2 = {"configurable": {"thread_id": "thread-2"}}
agent.invoke({"messages": [{"role": "user", "content": "Read /memories/style.txt"}]}, config=config2)
# Thread 2 reads the file saved by Thread 1
```

### FilesystemBackend — real disk (dev only)

```python
from deepagents import create_deep_agent
from deepagents.backends import FilesystemBackend
from langgraph.checkpoint.memory import MemorySaver

agent = create_deep_agent(
    backend=FilesystemBackend(root_dir=".", virtual_mode=True),  # Restrict access
    interrupt_on={"write_file": True, "edit_file": True},
    checkpointer=MemorySaver(),
)
```

> **Never use `FilesystemBackend` in a web server.** It exposes real disk. `virtual_mode=True` at minimum prevents `../` and `~/` escapes.

### Accessing the store in a custom tool

```python
from langchain.tools import tool, ToolRuntime

@tool
def get_user_preference(key: str, runtime: ToolRuntime) -> str:
    """Get a user preference from long-term storage."""
    result = runtime.store.get(("user_prefs",), key)
    return str(result.value) if result else "Not found"

@tool
def save_user_preference(key: str, value: str, runtime: ToolRuntime) -> str:
    """Save a user preference to long-term storage."""
    runtime.store.put(("user_prefs",), key, {"value": value})
    return f"Saved {key}={value}"
```

---

## 6. Subagents — task delegation

The main agent has a `task` tool that spawns a fresh subagent. The subagent runs autonomously and returns a final report.

A default `general-purpose` subagent is always available with the same tools/config as the main agent. Define custom subagents for specialized work.

| Use subagents when | Use main agent when |
|--------------------|---------------------|
| Task needs specialized tools | General-purpose tools are enough |
| Want to isolate complex work | Single-step operation |
| Need a clean context for main agent | Context bloat is acceptable |

### Custom subagent

```python
from deepagents import create_deep_agent
from langchain.tools import tool

@tool
def search_papers(query: str) -> str:
    """Search academic papers."""
    return f"Found 10 papers about {query}"

agent = create_deep_agent(
    subagents=[
        {
            "name": "researcher",
            "description": "Conduct web research and compile findings",
            "system_prompt": "Search thoroughly, return concise summary",
            "tools": [search_papers],
        }
    ],
)
# Main agent delegates via: task(agent="researcher", instruction="Research AI trends")
```

### Subagent with HITL

```python
from langgraph.checkpoint.memory import MemorySaver

agent = create_deep_agent(
    subagents=[
        {
            "name": "code-deployer",
            "description": "Deploy code to production",
            "system_prompt": "You deploy code after tests pass.",
            "tools": [run_tests, deploy_to_prod],
            "interrupt_on": {"deploy_to_prod": True},
        }
    ],
    checkpointer=MemorySaver(),   # Required for interrupts
)
```

### Subagents are stateless

Each `task(agent=...)` call starts a fresh subagent — provide complete instructions in one call.

```
# WRONG — subagent doesn't remember previous calls
task(agent="research", instruction="Find data")
task(agent="research", instruction="What did you find?")   # Fresh run!

# CORRECT — full instruction upfront
task(agent="research", instruction="Find data on AI, save to /research/, return summary")
```

### Subagents do NOT inherit skills

The `general-purpose` subagent inherits skills, but custom subagents do not. Pass skills explicitly:

```python
# WRONG — custom subagent has no access to main agent's skills
agent = create_deep_agent(
    skills=["/main-skills/"],
    subagents=[{"name": "helper", "tools": [...], "system_prompt": "..."}],
)

# CORRECT
agent = create_deep_agent(
    skills=["/main-skills/"],
    subagents=[{"name": "helper", "skills": ["/helper-skills/"], "tools": [...], "system_prompt": "..."}],
)
```

---

## 7. TodoList — task planning

Automatically included. Agent uses `write_todos` to plan multi-step work.

```
write_todos(todos: list[dict]) -> None
```

Each item has:
- `content` — description
- `status` — one of `"pending"`, `"in_progress"`, `"completed"`

### When to use

| Use TodoList when | Skip TodoList when |
|-------------------|---------------------|
| Complex multi-step tasks | Simple single-action tasks |
| Long-running operations | Fewer than 3 steps |

### Example

```python
from deepagents import create_deep_agent

agent = create_deep_agent()

result = agent.invoke(
    {"messages": [{"role": "user", "content": "Create a REST API: design models, implement CRUD, add auth, write tests"}]},
    config={"configurable": {"thread_id": "session-1"}},
)

# Access final todos
todos = result.get("todos", [])
for t in todos:
    print(f"[{t['status']}] {t['content']}")
```

Todo state requires a `thread_id` to persist across invocations.

---

## 8. Human-in-the-loop in Deep Agents

Same pattern as LangChain HITL — tools listed in `interrupt_on` pause execution until approved/edited/rejected.

### Setup

```python
from deepagents import create_deep_agent
from langgraph.checkpoint.memory import MemorySaver

agent = create_deep_agent(
    interrupt_on={
        "write_file": True,                                              # All decision types
        "execute_sql": {"allowed_decisions": ["approve", "reject"]},     # Limited decisions
        "read_file": False,                                              # No interrupt
    },
    checkpointer=MemorySaver(),   # REQUIRED for interrupts
)
```

### Approval workflow

```python
from deepagents import create_deep_agent
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command

agent = create_deep_agent(
    interrupt_on={"write_file": True},
    checkpointer=MemorySaver(),
)

config = {"configurable": {"thread_id": "session-1"}}

# Step 1 — agent proposes write_file; execution pauses
result = agent.invoke(
    {"messages": [{"role": "user", "content": "Write config to /prod.yaml"}]},
    config=config,
)

# Step 2 — check for interrupt
state = agent.get_state(config)
if state.next:
    print("Pending action")

# Step 3 — approve
result = agent.invoke(
    Command(resume={"decisions": [{"type": "approve"}]}),
    config=config,
)
```

### Reject with feedback

```python
result = agent.invoke(
    Command(resume={"decisions": [{"type": "reject", "message": "Run tests first"}]}),
    config=config,
)
```

### Edit before execution

```python
result = agent.invoke(
    Command(resume={"decisions": [{
        "type": "edit",
        "edited_action": {
            "name": "execute_sql",
            "args": {"query": "DELETE FROM users WHERE last_login < '2020-01-01' LIMIT 100"},
        },
    }]}),
    config=config,
)
```

Interrupts happen BETWEEN `invoke()` calls — always check for `__interrupt__` in the result after each call.

---

## 9. Skills in Deep Agents (SKILL.md format)

Deep Agents can load SKILL.md files on demand — progressive disclosure keeps context small until needed.

### Directory layout

```
skills/
└── my-skill/
    ├── SKILL.md        # Required
    ├── examples.py     # Optional
    └── templates/      # Optional
```

### SKILL.md format

```markdown
---
name: my-skill
description: Clear, specific description of what this skill does and when to use it
---

# Skill Name

## Overview
Brief purpose.

## When to Use
Conditions when this skill applies.

## Instructions
Step-by-step guidance for the agent.
```

### Skills vs memory (AGENTS.md)

| Skills | Memory (AGENTS.md) |
|--------|-------------------|
| On-demand loading | Always loaded at startup |
| Task-specific instructions | General preferences |
| Large documentation OK | Keep compact |
| SKILL.md in directories | Single AGENTS.md file |

### Loading skills from the filesystem

```python
from deepagents import create_deep_agent
from deepagents.backends import FilesystemBackend
from langgraph.checkpoint.memory import MemorySaver

agent = create_deep_agent(
    backend=FilesystemBackend(root_dir=".", virtual_mode=True),
    skills=["./skills/"],
    checkpointer=MemorySaver(),
)

result = agent.invoke(
    {"messages": [{"role": "user", "content": "Use the python-testing skill"}]},
    config={"configurable": {"thread_id": "session-1"}},
)
```

### Loading skills into a Store backend

For environments without filesystem access:

```python
from deepagents import create_deep_agent
from deepagents.backends import StoreBackend
from deepagents.backends.utils import create_file_data
from langgraph.store.memory import InMemoryStore

store = InMemoryStore()

skill_content = """---
name: python-testing
description: Best practices for Python testing with pytest
---

# Python Testing Skill
..."""

store.put(
    namespace=("filesystem",),
    key="/skills/python-testing/SKILL.md",
    value=create_file_data(skill_content),
)

agent = create_deep_agent(
    backend=lambda rt: StoreBackend(rt),
    store=store,
    skills=["/skills/"],
)
```

### Write specific descriptions

Vague skill descriptions cause undertriggering. Always include the specific domain AND trigger keywords:

```markdown
# WRONG
---
name: helper
description: Helpful skill
---

# CORRECT
---
name: python-testing
description: Python testing best practices with pytest fixtures, mocking, and async patterns
---
```

---

## 10. Common fixes

### Interrupts require a checkpointer

```python
# WRONG
agent = create_deep_agent(interrupt_on={"write_file": True})

# CORRECT
agent = create_deep_agent(
    interrupt_on={"write_file": True},
    checkpointer=MemorySaver(),
)
```

### StoreBackend requires a Store

```python
# WRONG — silent failure
agent = create_deep_agent(backend=lambda rt: StoreBackend(rt))

# CORRECT
agent = create_deep_agent(
    backend=lambda rt: StoreBackend(rt),
    store=InMemoryStore(),
)
```

### No thread_id → no conversation memory

```python
# WRONG
agent.invoke({"messages": [{"role": "user", "content": "Hi"}]})
agent.invoke({"messages": [{"role": "user", "content": "What did I say?"}]})

# CORRECT
config = {"configurable": {"thread_id": "user-123"}}
agent.invoke({"messages": [...]}, config=config)
agent.invoke({"messages": [...]}, config=config)
```

### StateBackend files don't cross threads

StateBackend is thread-scoped. Use the same `thread_id`, or route through `StoreBackend` via `CompositeBackend` to share files across threads.

### Path doesn't match the StoreBackend route prefix

With `routes={"/memories/": StoreBackend(rt)}`:

- `/prefs.txt` → ephemeral (no match)
- `/memories/prefs.txt` → persistent (matches)

### InMemoryStore in production

`InMemoryStore` is lost on restart. Use `PostgresStore`:

```python
store = PostgresStore(connection_string="postgresql://...")
```

### Missing frontmatter in SKILL.md

SKILL.md without YAML frontmatter will not load:

```markdown
# WRONG
# My Skill
This is my skill...

# CORRECT
---
name: my-skill
description: Python testing best practices with pytest fixtures and mocking
---
# My Skill
...
```

### Skills loaded without a backend

Skills require a backend to load from:

```python
# WRONG — skills silently unavailable
agent = create_deep_agent(skills=["./skills/"])

# CORRECT
agent = create_deep_agent(
    backend=FilesystemBackend(root_dir=".", virtual_mode=True),
    skills=["./skills/"],
)
```

### Subagents do not inherit skills (custom ones)

Pass `skills=[...]` explicitly to each custom subagent.

### FilesystemBackend needs `virtual_mode=True`

Without `virtual_mode=True`, `../` and `~/` can escape the `root_dir` restriction:

```python
backend = FilesystemBackend(root_dir="/project", virtual_mode=True)
```
